package oop.counter;
public class Decrementer {
    private int counter;
    public void decrementer(int counter) {
        this.counter = counter;
    }
}