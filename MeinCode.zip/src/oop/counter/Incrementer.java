package oop.counter;

public class Incrementer {

    private int counter;

    public void incrementer(int counter) {

        this.counter = counter;

    }
}
